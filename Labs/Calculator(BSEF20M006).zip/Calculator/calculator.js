
function display(x)
{
    st=String(x);
    if (st=="AC")
    {
        document.getElementById("screen").innerHTML=""; 
    }
    else if (st!= "ln" && st!= "sin" && st!= "tan" && st!= "cos" && st!="AC" && st!="=")
    {
        document.getElementById("screen").innerHTML+=x;  
    }
    else if (st=="=")
    {
        try
        {
            var content=document.getElementById("screen").innerText;
            content=content.replace("x","*");
            if(content[0]=="ln")
            {
                content.remove[content[0]];
                var x = eval(content);
                ans = Math.log10(x);
                document.getElementById("screen").innerHTML= ans;
            }
            if(content[0]=="logB2")
            {
                content.remove[content[0]];
                var x = eval(content);
                ans = Math.LOG2(x);
                document.getElementById("screen").innerHTML= ans;
            }
            if(content[0]=="logeB2")
            {
                content.remove[content[0]];
                var x = eval(content);
                ans = Math.LOG2E(x);
                document.getElementById("screen").innerHTML= ans;
            }
            if(content[0]=="sqrt")
            {
                content.remove[content[0]];
                var x = eval(content);
                ans = Math.sqrt(x);
                document.getElementById("screen").innerHTML= ans;
            }
            if(content[0]=="sin")
            {
                content.remove[content[0]];
                var x = eval(content);
                ans = ans * Math.PI / 180;
                ans = Math.sin(ans);
                document.getElementById("screen").innerHTML= ans;
            }
            if(content[0]=="cos")
            {
                content.remove[content[0]];
                var x = eval(content);
                ans = ans * Math.PI / 180;
                ans = Math.cos(ans);
                document.getElementById("screen").innerHTML= ans;
            }
            if(content[0]=="tan")
            {
                content.remove[content[0]];
                var x = eval(content);
                ans = ans * Math.PI / 180;
                ans = Math.tan(ans);
                document.getElementById("screen").innerHTML= ans;
            }
            else{
                console.log(content);
                var ans = eval(content);
                document.getElementById("screen").innerHTML= ans;
            }
            
        }
        catch(error)
        {
            document.getElementById("screen").innerHTML="Error in Syntax"
            console.log(error);
        }
    }
}

