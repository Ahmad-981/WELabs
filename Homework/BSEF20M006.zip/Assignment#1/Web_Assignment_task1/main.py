import pymysql
from DBHandler import DBHandler 
from User import User
from faculty import Faculty
from Student import Student

#Taking input from the user
us5 = User("","")
us5.username= input("Enter Username: ")
us5.password= input("Enter Password: ")
db = DBHandler("localhost","root","ahmad6","fcit")
db.insertUser(us5)

fac = Faculty("", "")
fac.designation = input("Enter Designation: ")
fac.subject = input("Enter Subject: ")
db.insertFaculty(fac)

student1 = Student("","","")
student1.semester = input("Enter Semester: ")
student1.cgpa = input("Enter cgpa: ")
student1.major = input("Enter Major: ")
db.insertStudent(student1)