import pymysql
from faculty import Faculty
from Student import Student

class DBHandler:
    def __init__(self,host,user,password,database):
        self.host=host
        self.user = user
        self.password=password
        self.database=database

    def insertUser(self, us):
        mydb = None
        mydbCursor=None
        try:
            
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query = ("INSERT INTO user(username, password) VALUES(%s, %s)")
            #query= ("Update user Set username = %s where password = %s ")
            val=(us.username, us.password)
            mydbCursor.execute(query, val)
            mydb.commit()

        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close()

    def insertFaculty(self, fac):
        mydb = None
        mydbCursor=None
        try:
            
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query = ("INSERT INTO faculty(designation, subject) VALUES(%s, %s)")
            val=(fac.designation, fac.subject)
            mydbCursor.execute(query, val)
            mydb.commit()

        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close()

    def insertStudent(self, st):
        mydb = None
        mydbCursor=None
        try:
            
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query = ("INSERT INTO student(semester, cgpa, major) VALUES(%s, %s, %s)")
            val=(st.semester, st.cgpa, st.major)
            mydbCursor.execute(query, val)
            mydb.commit()

        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close()
