class User:
    def __init__(self, u, p):
        self.username = u
        self.password = p

    @property
    def getUsername(self):
        return self.username
    @property
    def getPasword(self):
        return self.password

    def setUsername(self, u):
        self.username =u
    def setPassword(self, pas):
        self.password =pas