from User import User

class Student(User):
    def __init__(self, s,cgp, maj):
        self.semester = s
        self.cgpa = cgp
        self.major = maj

    @property
    def getSemester(self):
        return self.semerter
    @property
    def setCGPA(self, cgp):
        self.cgpa = cgp

    @property
    def setMajor(self, maj):
        self.major = maj

    def setSemester(self, sem):
        self.semerter = sem

    def setCGPA(self, gpa):
        self.cgpa= gpa
