
class AccountNotFound(Exception):
     print(Exception , ". Enter Credentials Again!")
class DataNotUpdated(Exception):
    print(Exception , ". Sorry Data Not Updated ")
