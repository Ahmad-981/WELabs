import pymysql
from faculty import Faculty
from Student import Student
from User import User


class DBHandler:
    def __init__(self,host,user,password,database):
        self.host=host
        self.user = user
        self.password=password
        self.database=database

    def registerFaculty(self, fac):
        mydb = None
        mydbCursor=None
        try:
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query = ("INSERT INTO faculty(designation, subject) VALUES(%s, %s)")
            val=(fac.designation, fac.subject)
            mydbCursor.execute(query, val)
            mydb.commit()
        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close()

    def registerUser(self, us):
        mydb = None
        mydbCursor=None
        try:
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query = ("INSERT INTO user(username, password) VALUES(%s, %s)")
            #query= ("Update user Set username = %s where password = %s ")
            val=(us.username, us.password)
            mydbCursor.execute(query, val)
            mydb.commit()
        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close()

    def registerStudent(self, st):
        mydb = None
        mydbCursor=None
        try:
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query = ("INSERT INTO student(semester, cgpa, major) VALUES(%s, %s, %s)")
            val=(st.semester, st.cgpa, st.major)
            mydbCursor.execute(query, val)
            mydb.commit()
        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close()

    def getFaculty(self, cred):
        mydb = None
        mydbCursor=None
        try:
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query = ("SELECT * from user WHERE username = %s AND password = %s")
            val=(cred.username, cred.password)
            mydbCursor.execute(query, val)
            result = mydbCursor.fetchall()
            return result
        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close()   

    def getStudent(self, cred):
        mydb = None
        mydbCursor=None
        try:
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query = ("SELECT * from user WHERE username = %s AND password = %s")
            val=(cred.username, cred.password)
            mydbCursor.execute(query, val)
            result = mydbCursor.fetchall()
            return result
        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close()      

    def updateFaculty(self, cred, updData):
        mydb = None
        mydbCursor=None
        try:
            
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query= ("Update faculty Set designation = %s, subject = %s WHERE username = %s AND password = %s")
            val=(updData.designation, updData.password, cred.username, cred.password)
            mydbCursor.execute(query, val)
            mydb.commit()

        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close() 

    def updateStudent(self, cred, updData):
        mydb = None
        mydbCursor=None
        try:
            
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query= ("Update student Set semester = %s, cgpa = %s WHERE username = %s AND password = %s")
            val=(updData.semester, updData.cgpa, cred.username, cred.password)
            mydbCursor.execute(query, val)
            mydb.commit()

        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close() 

    def deleteStudent(self, idd):
        mydb = None
        mydbCursor=None
        try:
            
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query= ("DELETE FROM student WHERE id = %s")
            val=(idd)
            mydbCursor.execute(query, val)
            mydb.commit()
        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close() 

    def deleteFaculty(self, idd):
        mydb = None
        mydbCursor=None
        try:
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query= ("DELETE FROM faculty WHERE id = %s")
            val=(idd)
            mydbCursor.execute(query, val)
            mydb.commit()
        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close() 

    def verifyUser(self, cred):
        mydb = None
        mydbCursor=None
        try:
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            mydbCursor = mydb.cursor()
            query = ("SELECT * from user")
            #val=(cred.username, cred.password)
            mydbCursor.execute(query)
            result = mydbCursor.fetchall()
            for x in result:
                if x==cred:
                    status = "Success"
                else:
                    status = "Failed"
            print(x)  

        except Exception as e:
            print(str(e))
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close() 
