import pymysql
from DBHandler import DBHandler 
#from Exception import Exception
from User import User
from faculty import Faculty
from Student import Student
from Controller import Controller


class View(Controller):
    def showMenu():
            choice = int(input("""
                    To REGISTER:                Press 1
                    To Login as Student:        Press 2
                    To Login as Faculty:        Press 3
                    Please enter your choice: """))
            con = Controller()
            if choice == 1:
                #General Registeration
                user = User("","")
                user.username = input("Enter Username: ")
                user.password = input("Enter Password: ")
                con.register(user)

                #Specific Registration
                choice2 = (input("""
                                    To Register as a Student:     Press 1 
                                    To Register as a Faculty:     Press 2
                                    Please enter your choice: """))
                if choice2 == 1:       #Student
                    st = Student("","", "")
                    st.semerter= input("Enter Semester: ")
                    st.cgpa = input("Enter CGPA: ")
                    st.major = input("Enter Major: ")
                    con.registerAsStudent(st)


                else:                   #Faculty
                    fac = Faculty("","")        
                    fac.designation = input("Enter Designation: ")
                    fac.subject = input("Enter Subject: ")
                    con.registerAsFaculty(fac)

            if choice == 2:
                try:
                    user2 = User("","")
                    user2.username = input("Enter Username: ")
                    user2.password = input("Enter Password: ")
                    con.verifyUser(user2)
                    choice3 = int(input("""
                        ***-Student-Login-***
                        View Profile:       Press 1
                        Edit Profile:       Press 2
                        Delete Profile:     Press 3
                        Please enter your choice:"""))
                    if choice3== 1:
                            con.viewStudentProfile(user2)
                    elif choice3 == 2:
                            con.editStudentProfile(user2)
                    elif choice3 == 3:
                            con.deleteStudentProfile(user2)
                except Exception:
                    raise ("Account Not Found")

            else:
                    user3 = User("","")
                    user3.username = input("Enter Username: ")
                    user3.password = input("Enter Password: ")
                    con.verifyUser(user3)
                    choice4 = int(input("""
                        ***-Faculty-Login-***
                        View Profile:       Press 1
                        Edit Profile:       Press 2
                        Delete Profile:     Press 3
                        Please enter your choice:"""))
                    
                    con.registerAsFaculty(fac)
                    if choice4== 1:
                            con.viewFacultyProfile(user3)
                    elif choice4 == 2:
                            con.editFacultyProfile(user3)
                    elif choice4 == 3:
                            con.deleteFacultyProfile(user3)





View.showMenu()


