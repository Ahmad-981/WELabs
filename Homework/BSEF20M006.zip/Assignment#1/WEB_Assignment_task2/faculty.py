from User import User

class Faculty(User):
    def __init__(self, desg, subj):
        self.designation = desg
        self.subject = subj
    @property
    def getDesignation(self):
        return self.designation
    @property
    def getSubject(self):
        return self.subject

    def setDesig(self, des):
        self.designation = des

    def setID(self, sub):
        self.subject= sub

  
