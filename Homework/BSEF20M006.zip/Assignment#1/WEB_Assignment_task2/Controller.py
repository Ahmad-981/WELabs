from DBHandler import DBHandler 
from User import User
from faculty import Faculty
from Student import Student

db = DBHandler("localhost", "root","ahmad6", "fcit")        #Global Declaration of Database Object

class Controller():
    #Registration
    def register(self,user):
        db.registerUser(user)

    #Verification
    def verifyUser(self,crd):
        db.verifyUser(crd)

    #Registration as Student and Faculty
    def registerAsStudent(self,us):
        db.registerStudent(us)
    def registerAsFaculty(self,u):
        db.registerFaculty(u)

    #View Profile
    def viewFacultyProfile(self, u):
        db.getFaculty(u)
    def viewStudentProfile(self, u):
        db.getStudent(u)

    #Edit Profile
    def editStudentProfile(self, uss):
        db.updateStudent(uss)
    def editFacultyProfile(self, user):
        db.updateFaculty(user)

    #Delete Profile
    def deleteStudentProfile(self, user):
        db.deleteStudent(user)
    def deleteFacultyProfile(self, ser):
        db.deleteFaculty(ser)    

